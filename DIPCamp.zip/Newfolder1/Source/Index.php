<?php


require 'DB.php';


?>


<html>

	<head> 
				
		<link rel="icon" type="image/png" href="../Pics/Fav.ico">
		
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		
		<link rel="stylesheet" type="text/css" href="../ScriptsStylesFonts/StyleSheet.css">
		
	</head>
	
	<body>
	
	<div class="container">
		
			  <div class="jumbotron">
			  
					<div id="myCarousel" class="carousel slide" data-ride="carousel">
					
					  <ol class="carousel-indicators">
					  
						<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
						<li data-target="#myCarousel" data-slide-to="1"></li>
						<li data-target="#myCarousel" data-slide-to="2"></li>
						<li data-target="#myCarousel" data-slide-to="3"></li>
						
					  </ol>

					 
					  <div class="carousel-inner" role="listbox">
						<div class="item active">
						  <img src="../Pics/Camp1.jpg" >  
						</div>

						<div class="item">
						 <img src="../Pics/Camp2.jpg" >  
						</div>

						<div class="item">
						 <img src="../Pics/Camp3.jpg" >  
						</div>

						<div class="item">
						  <img src="../Pics/Camp4.jpg" >  
						</div>
					  </div>

				
					  <a class="left carousel-control"
							href="#myCarousel" role="button" 
							data-slide="prev">
							
						<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
						
						<span class="sr-only">Previous</span>
						
					  </a>
					  
					  <a class="right carousel-control" 
							href="#myCarousel" 
							role="button" 
							data-slide="next">
							
						<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
						
						<span class="sr-only">Next</span>
						
					  </a>
					  
					</div>
	         
			 </div>
			 		  
		</div>
		

	<div class="container">	
		
			<nav class="navbar navbar-default navbar-fixed-top navbar-inverse">
			
				  <div class="container-fluid">
				  
						<div class="navbar-header">
						
							<a class="navbar-brand" > </a>
						
						</div>
						
							<ul class="nav navbar-nav">
							
								  <li class="active"><a href="">Map</a></li>
								   							  					
							</ul>
							
							<ul class="nav navbar-nav navbar-right">
								
								  <li><a href="">Register</a></li>
							
							</ul>
							
				  </div>
				  
			</nav>
			
		</div>
		
		
	<div class="container">
	
		<div class="panel panel-heading panel-default">
	
			<h2 class="text-center"> Camping Grid </h2>
		
		</div>
		
		<?php
		
		$sql						= "SELECT CampingID FROM camping ORDER BY CampingID";
		
		mysql_select_db('festival_db');
		
		$values 				= mysql_query( $sql, $conn );
		 
		if(!$values ) 
		   {
				  die('Could not get data: ' . mysql_error());
		   }
			
			for ($i = 0 ; $i < 50 ;)	
			{
				echo "<div class='row'>".
						"<div class='col-sm-1'>".
						"</div>";
								
				   while($row = mysql_fetch_array($values, MYSQL_BOTH)) 
				  {
						 echo  "<div class='col-sm-1'>".
								   "<div class='panel panel-default' data-toggle='modal' data-target='#myModal{$row['CampingID']}'>".
								   "<div class='panel-body text-center'>".
								   "{$row['CampingID']}". 
								   "</div>".
								   "</div>".
								   "</div>";
								   
						 echo "<div class='modal fade' id='myModal{$row['CampingID']}' role='dialog'>".
    
									"<div class='modal-dialog'>".
									   
									  "<div class='modal-content'>".
									  
											"<div class='modal-header'>".
											
											  "<button type='button' class='close' data-dismiss='modal'>&times;</button>".
											  "<h4 class='modal-title'>Camp Grid  {$row['CampingID']} </h4>".
											  
											"</div>".
											
										"<div class='modal-body'>".
										
											  "<p>{$row['CampingID']}</p>".
										
										"</div>".
										
										"<div class='modal-footer'>".
										
											  "<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>".
									   
									   "</div>".
									   
									  "</div>".
									  
									"</div>".
									
								  "</div>";		   
								 							   
						$i++;
						
						if ($i % 10 == 0)
							{
								break;
							}
													
				  }
				  
				 echo "<div class='col-sm-1'>".
						  "</div>" .
						  "</div>";
								
			}
			
			mysql_close($conn);
			
		?>
		
		
		
		
	</div>

	</body>
	
	<footer>
			<?php
				require 'footer.php';
			?>
	</footer>

</html>